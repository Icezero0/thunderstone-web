"""Reproducible, in-memory effect interpreter scenarios for the local preview."""

from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
from typing import Callable

from engine.catalog.repository import load_catalog
from engine.effects.compiler import compile_ruleset, load_ruleset
from engine.setup import start_game
from engine.turn import TurnError, apply_command, legal_commands


CASES = (
    {"id": "trophy-versus-battle", "title": "无缚者：战斗效果与手牌战利品", "kind": "真实卡牌",
     "focus": "大厅怪物只触发战斗疾病；两张手牌战利品提供魔法攻击 +2"},
    {"id": "refill-trap-resume", "title": "驱逐：补牌陷阱中断后继续", "kind": "真实卡牌",
     "focus": "返回怪物 → 陷阱选英雄 → 原能力选费用 → 抽牌"},
    {"id": "disease-choice", "title": "先知：摧毁疾病后抽牌", "kind": "真实卡牌",
     "focus": "select → cost_gate → destroy → draw；多候选暂停与继续"},
    {"id": "monster-count", "title": "先知：按手牌怪物数抽牌", "kind": "真实卡牌",
     "focus": "count 查询、乘法表达式与动态抽牌"},
    {"id": "thornwood-tie", "title": "荆木：最高价格并列", "kind": "真实卡牌",
     "focus": "ACTION_EXITED 触发、max_by、选择后继续回合清理"},
    {"id": "thornwood-unique", "title": "荆木：唯一最高价格", "kind": "真实卡牌",
     "focus": "单候选自动选择并完成回合"},
    {"id": "condition-schedule", "title": "条件、循环与延迟效果", "kind": "合成 DSL",
     "focus": "all/not/exists/compare、if、for_each、repeat、schedule"},
    {"id": "condition-false", "title": "条件不满足与 else 分支", "kind": "合成 DSL",
     "focus": "any 为假时不可发动；if 进入 else；add 表达式"},
    {"id": "cost-rollback", "title": "费用不足时整条命令回滚", "kind": "合成 DSL",
     "focus": "spend_xp 失败、无收益、输入状态不变"},
    {"id": "cost-gain-discard", "title": "支付费用、获得牌并弃牌", "kind": "合成 DSL",
     "focus": "cost_gate、spend_xp、gain_card、select、discard"},
    {"id": "battle-modifiers", "title": "战斗临时修正", "kind": "合成 DSL",
     "focus": "mod_attack、mod_light 与战斗结算的计算轨迹"},
)


@lru_cache(maxsize=1)
def _catalog():
    return load_catalog()


def _config(environment: str | None = None) -> dict:
    return {
        "mode": "classic",
        "counts": {"village_groups": 8, "hero_groups": 4, "monster_groups": 3},
        "selection": {
            "village": {"fixed_randomizer_ids": []},
            "hero": {"fixed_randomizer_ids": []},
            "monster": {"fixed_randomizer_ids": []},
            "dungeon_features": {"mode": "manual"},
            "guardian": {"random_count": 0, "fixed_card_ids": []},
            "environment": {"random_count": 0,
                            "fixed_card_ids": [environment] if environment else []},
            "trap": {"random_count": 0, "fixed_group_ids": []},
            "treasure": {"random_count": 0, "fixed_group_ids": []},
            "thunderstone": {"fixed_card_ids": []},
        },
        "instance_multipliers": {"village": 1, "hero": 1, "monster": 1},
    }


def _synthetic(ability_id: str, body: dict, *, action: str = "village",
               conditions: list[dict] | None = None) -> dict:
    return {"schema_version": "thunderstone.effects/1", "abilities": [{
        "id": ability_id, "source_card_id": "TS-0001", "kind": "activated",
        "actions": [action], "source_zone": "active_hand",
        "usage": "once_per_turn", "conditions": conditions or [], "body": body,
    }]}


FLOW_RULE = _synthetic(
    "TS-0001-A99", {"op": "sequence", "children": [
        {"op": "if", "condition": {"compare": {
            "left": {"count": {"zone": "active_hand", "card_id": "TS-0001"}},
            "op": "ge", "right": 1}},
         "then": {"op": "gain_xp", "amount": 1},
         "else": {"op": "gain_xp", "amount": 9}},
        {"op": "for_each", "query": {"zone": "active_hand", "card_id": "TS-0001"},
         "bind": "militia", "body": {"op": "gain_xp", "amount": 1}},
        {"op": "repeat", "times": 2, "limit": 2,
         "body": {"op": "mod_gold", "amount": 1}},
        {"op": "schedule", "event": "TURN_WILL_END",
         "body": {"op": "gain_xp", "amount": 3}},
    ]}, conditions=[{"all": [
        {"exists": {"zone": "active_hand", "card_id": "TS-0001"}},
        {"not": {"setting_active": "TS-0199"}},
    ]}])

COST_RULE = _synthetic("TS-0001-A96", {"op": "sequence", "children": [
    {"op": "cost_gate", "cost": {"op": "spend_xp", "amount": 2},
     "then": {"op": "gain_card", "card_id": "TS-0003"}},
    {"op": "select", "query": {"zone": "active_hand", "card_id": "TS-0002"},
     "bind": "dagger", "then": {"op": "discard", "target": {"var": "dagger"}}},
]})

BATTLE_RULE = _synthetic("TS-0001-A97", {"op": "sequence", "children": [
    {"op": "mod_attack", "amount": 2},
    {"op": "mod_light", "amount": 1},
]}, action="dungeon")

FALSE_RULE = {"schema_version": "thunderstone.effects/1", "abilities": [
    _synthetic("TS-0001-A94", {"op": "gain_xp", "amount": 9}, conditions=[
        {"any": [
            {"exists": {"zone": "active_hand", "card_id": "TS-0714"}},
            {"exists": {"zone": "active_hand", "subcategory": "怪物"}},
        ]},
    ])["abilities"][0],
    _synthetic("TS-0001-A95", {"op": "if", "condition": {"any": [
        {"exists": {"zone": "active_hand", "card_id": "TS-0714"}},
        {"exists": {"zone": "active_hand", "subcategory": "怪物"}},
    ]}, "then": {"op": "gain_xp", "amount": 9},
        "else": {"op": "gain_xp", "amount": {"add": [1, 2]}}})["abilities"][0],
]}


def _label(state: dict, cards: dict, instance_id: str) -> dict:
    instance = state["instances"].get(instance_id)
    if instance is None:
        return {"instance_id": instance_id, "card_id": None, "name": "已移除"}
    card_id = instance["card_id"]
    card = cards[card_id]
    name = next((card[key] for key in ("name_zh", "card_name", "name", "title")
                 if card.get(key)), card_id)
    return {"instance_id": instance_id, "card_id": card_id, "name": name}


def _view(state: dict, cards: dict) -> dict:
    player = state["active_player_id"]
    zones = state["zones"]
    choice = state.get("pending_choice")
    supply = []
    for zone, pile in sorted(zones.items()):
        if zone.startswith("village_supply:") and pile:
            supply.append({"zone": zone, "count": len(pile),
                           "top": _label(state, cards, pile[0])})
    choice_view = None
    if choice:
        if choice["kind"] == "effect_purchase":
            candidates = [{"card_id": row["card_id"], "instance_id": "buy:" + row["card_id"],
                           "name": cards[row["card_id"]]["name"]} for row in choice["options"]]
        elif choice["kind"] == "effect_order":
            candidates = [{"card_id": None, "instance_id": row["effect_id"], "name": row["ability_id"]} for row in choice["effects"]]
        else:
            candidates = [_label(state, cards, item) for item in choice["candidate_instance_ids"]]
        choice_view = {"kind": choice["kind"], "ability_id": choice.get("ability_id", choice.get("event")),
                       "player_id": choice["player_id"], "candidates": candidates}
    return {
        "version": state["game_version"], "turn": state["turn_number"],
        "player": player, "phase": state["phase"], "subphase": state["subphase"],
        "action": state["chosen_action"],
        "xp": state["players"][player]["xp"],
        "gold": state["players"][player]["temporary_gold"],
        "battle_modifiers": deepcopy((state.get("battle_context") or {}).get("modifiers", {})),
        "hand": [_label(state, cards, item) for item in zones[f"player:{player}:hand"]],
        "draw_count": len(zones[f"player:{player}:draw"]),
        "discard": [_label(state, cards, item) for item in zones[f"player:{player}:discard"]],
        "destroyed": [_label(state, cards, item) for item in zones.get("destroyed", [])],
        "supply": supply,
        "halls": [{"zone": zone, "cards": [_label(state, cards, item) for item in pile]}
                  for zone, pile in sorted(zones.items()) if zone.startswith("hall:")],
        "choice": choice_view,
        "scheduled": [{"ability_id": item["ability_id"], "event": item["event"]}
                      for item in state.get("scheduled_effects", [])],
        "ability_uses": deepcopy(state.get("ability_uses", {})),
    }


class _Run:
    def __init__(self, case_id: str, seed: str, *, environment: str | None = None,
                 custom_rule: dict | None = None):
        self.meta = next(item for item in CASES if item["id"] == case_id)
        self.snapshot = _catalog()
        self.cards = self.snapshot.cards
        self.rule_json = custom_rule
        self.effects = (compile_ruleset(custom_rule, self.cards) if custom_rule
                        else load_ruleset(self.cards))
        request = {"match_id": f"effect-lab-{case_id}",
                   "player_ids": ["alice", "bob"], "rng_seed": seed,
                   "config": _config(environment)}
        self.state = start_game(request, snapshot=self.snapshot)["state"]
        self.state["effects_version"] = self.effects.version
        self.steps: list[dict] = []
        self.checks: list[dict] = []
        self.seed = seed
        self.setup_config = request["config"]

    @property
    def player(self) -> str:
        return self.state["active_player_id"]

    def fixture(self, description: str, change: Callable[[dict], None]) -> None:
        before = _view(self.state, self.cards)
        change(self.state)
        self.steps.append({"type": "fixture", "title": description,
                           "before": before, "after": _view(self.state, self.cards),
                           "events": []})

    def add_hand(self, card_id: str) -> str:
        instance_id = f"CI-{self.state['next_instance_sequence']:06d}"
        self.state["next_instance_sequence"] += 1
        self.state["instances"][instance_id] = {
            "card_id": card_id, "owner_player_id": self.player,
            "origin": "effect_lab_fixture", "flags": {},
        }
        self.state["zones"][f"player:{self.player}:hand"].append(instance_id)
        return instance_id

    def first_hand(self, card_id: str) -> str:
        return next(item for item in self.state["zones"][f"player:{self.player}:hand"]
                    if self.state["instances"][item]["card_id"] == card_id)

    def clear_zone(self, zone: str) -> None:
        pile = self.state["zones"][zone]
        for item in pile:
            self.state["instances"][item]["owner_player_id"] = None
        self.state["zones"].setdefault("destroyed", []).extend(pile)
        pile.clear()

    def add_to_zone(self, card_id: str, zone: str) -> str:
        item = self.add_hand(card_id)
        self.state["zones"][f"player:{self.player}:hand"].remove(item)
        self.state["zones"].setdefault(zone, []).append(item)
        self.state["instances"][item]["owner_player_id"] = zone.split(":")[1] if zone.startswith("player:") else None
        return item

    def do(self, kind: str, **arguments: object) -> dict:
        before = _view(self.state, self.cards)
        actor = self.state["pending_choice"]["player_id"] if self.state["pending_choice"] else self.player
        command = {"type": kind, "player_id": actor,
                   "expected_version": self.state["game_version"], **arguments}
        result = apply_command(self.state, command, snapshot=self.snapshot,
                               effects=self.effects, trace_effects=True)
        self.state = result["state"]
        self.steps.append({"type": "command", "title": kind,
                           "command": command, "before": before,
                           "after": _view(self.state, self.cards),
                           "events": result["events"],
                           "effect_trace": result["effect_trace"],
                           "legal_commands": result["legal_commands"]})
        return result

    def reject(self, kind: str, **arguments: object) -> str:
        before = deepcopy(self.state)
        command = {"type": kind, "player_id": self.player,
                   "expected_version": self.state["game_version"], **arguments}
        try:
            apply_command(self.state, command, snapshot=self.snapshot,
                          effects=self.effects)
        except TurnError as error:
            self.steps.append({"type": "rejected", "title": kind,
                               "command": command, "before": _view(before, self.cards),
                               "after": _view(self.state, self.cards),
                               "events": [], "error": str(error)})
            self.check("被拒绝的命令未改变输入状态", self.state == before)
            return str(error)
        self.check("预期被拒绝的命令被接受", False)
        raise AssertionError(f"{kind} unexpectedly succeeded")

    def check(self, title: str, passed: bool, detail: str = "") -> None:
        self.checks.append({"title": title, "passed": bool(passed), "detail": detail})

    def output(self) -> dict:
        return {"case": self.meta, "seed": self.seed, "config": self.setup_config,
                "ruleset_version": self.effects.version,
                "abilities": ([item for item in self.rule_json["abilities"]]
                              if self.rule_json else [
                                  {"id": item.id, "source_card_id": item.source_card_id,
                                   "kind": item.kind, "conditions": item.conditions,
                                   "body": item.body}
                                  for item in self.effects.abilities
                                  if item.id in {event.get("ability_id")
                                                 for step in self.steps
                                                 for event in step["events"]}]),
                "initial": self.steps[0]["before"] if self.steps else _view(self.state, self.cards),
                "steps": self.steps, "checks": self.checks,
                "passed": bool(self.checks) and all(item["passed"] for item in self.checks)}


def _choice(run: _Run, choice_index: int) -> str:
    candidates = run.state["pending_choice"]["candidate_instance_ids"]
    if not 0 <= choice_index < len(candidates):
        raise ValueError(f"choice_index must be in 0..{len(candidates) - 1}")
    selected = candidates[choice_index]
    run.do("ResolveChoice", instance_id=selected)
    return selected


def run_case(case_id: str, *, choice_index: int = 0) -> dict:
    """Run one fresh fixture through public setup/turn APIs; never persist state."""
    if case_id not in {item["id"] for item in CASES}:
        raise KeyError(case_id)
    if not isinstance(choice_index, int) or choice_index < 0:
        raise ValueError("choice_index must be nonnegative")

    if case_id == "trophy-versus-battle":
        run = _Run(case_id, "lab-trophy-versus-battle")
        ids = {}
        def arrange(state):
            for zone in list(state["zones"]):
                if zone.startswith(("hall:", "dungeon:")) or zone == f"player:{run.player}:hand":
                    run.clear_zone(zone)
            ids["hand"] = [run.add_hand("TS-0603") for _ in range(2)]
            ids["target"] = run.add_to_zone("TS-0603", "hall:main")
        run.fixture("手牌放两张无缚者，大厅放另一张无缚者", arrange)
        run.do("ChooseAction", action="dungeon")
        result = run.do("DeclareBattleTarget", target_instance_id=ids["target"])
        battle = next(e for e in result["events"] if e["kind"] == "battle_resolved")
        run.check("两张手牌战利品提供魔法攻击 +2", battle["calculation"]["magic_attack"] == 2)
        run.check("大厅怪物不提供魔法攻击", ids["target"] not in {c["instance_id"] for c in battle["calculation"]["components"]})
        run.check("只有被攻击的怪物触发一次疾病", sum(e["kind"] == "disease_taken_from_supply" for e in result["events"]) == 1)
    elif case_id == "refill-trap-resume":
        run = _Run(case_id, "lab-refill-trap")
        ids = {}
        def arrange(state):
            for zone in list(state["zones"]):
                if zone.startswith(("hall:", "dungeon:")) or zone.startswith("player:"):
                    run.clear_zone(zone)
            ids["source"] = run.add_hand("TS-0275")
            ids["hero"] = run.add_hand("TS-0001")
            run.add_hand("TS-0302")
            ids["cost"] = run.add_hand("TS-0003")
            for _ in range(3):
                run.add_to_zone("TS-0476", "hall:main")
                run.add_to_zone("TS-0001", f"player:{run.player}:draw")
            ids["trap"] = run.add_to_zone("TS-0688", "dungeon:main")
            for _ in range(4):
                run.add_to_zone("TS-0476", "dungeon:main")
        run.fixture("大厅三只怪物，牌堆顶为斩首陷阱，手牌含驱逐与两名英雄", arrange)
        run.do("ChooseAction", action="dungeon")
        run.do("ActivateAbility", ability_id="TS-0275-A01", source_instance_id=ids["source"])
        _choice(run, choice_index)
        run.check("补牌时先暂停到陷阱的选择", run.state["pending_choice"]["ability_id"] == "TS-0688-A01")
        run.do("ResolveChoice", instance_id=ids["hero"])
        run.check("陷阱完成后恢复原能力的费用选择", run.state["pending_choice"]["ability_id"] == "TS-0275-A01")
        result = run.do("ResolveChoice", instance_id=ids["cost"])
        run.check("原能力继续抽牌", any(e["kind"] == "effect_draw" and e["ability_id"] == "TS-0275-A01" for e in result["events"]))
        run.check("陷阱和费用牌都已正确处理", {ids["trap"], ids["cost"]} <= set(run.state["zones"]["destroyed"]))
        run.check("可继续地下城准备，没有残留选择", run.state["pending_choice"] is None and run.state["subphase"] == "DUNGEON_PREPARE")
    elif case_id == "disease-choice":
        run = _Run(case_id, "effect-lab-disease")
        added = []
        def arrange(state: dict) -> None:
            added.append(run.add_hand("TS-0437"))
            added.extend((run.add_hand("TS-0714"), run.add_hand("TS-0714")))
        run.fixture("在手牌加入先知和两张普通疾病", arrange)
        run.do("ChooseAction", action="village")
        run.do("ActivateAbility", ability_id="TS-0437-A02",
               source_instance_id=added[0])
        pending = run.state["pending_choice"]
        run.check("两张疾病均为可选目标", set(pending["candidate_instance_ids"]) == set(added[1:]))
        hand_before = len(run.state["zones"][f"player:{run.player}:hand"])
        selected = _choice(run, choice_index)
        run.check("所选疾病被移除", selected not in run.state["instances"])
        run.check("另一张疾病仍在手牌", any(item in run.state["zones"][f"player:{run.player}:hand"]
                                            for item in added[1:] if item != selected))
        run.check("抽两张牌，手牌净增一张",
                  len(run.state["zones"][f"player:{run.player}:hand"]) == hand_before + 1)
        run.check("效果只能使用一次", not any(
            option.get("ability_id") == "TS-0437-A02"
            for command in legal_commands(run.state, snapshot=run.snapshot, effects=run.effects)
            for option in command.get("options", [])))
    elif case_id == "monster-count":
        run = _Run(case_id, "effect-lab-count")
        added = []
        def arrange(state: dict) -> None:
            added.append(run.add_hand("TS-0437"))
            monster = state["instances"][state["zones"]["hall:main"][0]]["card_id"]
            added.extend((run.add_hand(monster), run.add_hand(monster)))
        run.fixture("在手牌加入先知和两张怪物", arrange)
        run.do("ChooseAction", action="village")
        result = run.do("ActivateAbility", ability_id="TS-0437-A03",
                        source_instance_id=added[0])
        draw = next(item for item in result["events"] if item["kind"] == "effect_draw")
        run.check("两张怪物使表达式 2 × count 求值为 4", draw["requested"] == 4)
        run.check("实际抽到四张牌", len(draw["instance_ids"]) == 4)
    elif case_id in ("thornwood-tie", "thornwood-unique"):
        tie = case_id == "thornwood-tie"
        run = _Run(case_id, "8" if tie else "0", environment="TS-0193")
        actor = run.player
        supply = [pile[0] for zone, pile in run.state["zones"].items()
                  if zone.startswith("village_supply:") and pile]
        price = lambda item: int(run.cards[run.state["instances"][item]["card_id"]][
            "wiki_购买价格"])
        highest = max(map(price, supply))
        candidates = {item for item in supply if price(item) == highest}
        run.check("场景具备预期最高价候选数", len(candidates) > 1 if tie else len(candidates) == 1)
        run.do("ChooseAction", action="rest")
        result = run.do("FinishRest")
        if tie:
            run.check("并列候选在行动退出时暂停回合",
                      run.state["subphase"] == "ACTION_EXIT_EFFECTS"
                      and run.state["turn_number"] == 1)
            run.check("只提供最高价格的候选",
                      set(run.state["pending_choice"]["candidate_instance_ids"]) == candidates)
            selected = _choice(run, choice_index)
        else:
            run.check("唯一候选无需交互", run.state["pending_choice"] is None)
            selected = next(iter(candidates))
        run.check("选中的村庄供应牌顶被摧毁", selected in run.state["zones"]["destroyed"])
        run.check("效果完成后才交给下位玩家", run.state["turn_number"] == 2
                  and run.state["active_player_id"] != actor)
    elif case_id == "condition-schedule":
        run = _Run(case_id, "effect-lab-flow", custom_rule=FLOW_RULE)
        actor = run.player
        militia = [item for item in run.state["zones"][f"player:{run.player}:hand"]
                   if run.state["instances"][item]["card_id"] == "TS-0001"]
        if not militia:
            run.fixture("加入民兵，以满足条件和循环查询", lambda state: run.add_hand("TS-0001"))
            militia = [run.first_hand("TS-0001")]
        run.do("ChooseAction", action="village")
        activation = run.do("ActivateAbility", ability_id="TS-0001-A99",
                            source_instance_id=militia[0])
        run.check("条件分支和逐张循环累计经验", run.state["players"][run.player]["xp"] == 1 + len(militia))
        run.check("结束回合效果已排程", len(run.state["scheduled_effects"]) == 1)
        gold_events = [event for event in activation["events"]
                       if event["kind"] == "effect_resource_changed"
                       and event.get("op") == "mod_gold"]
        run.check("重复两次，各增加 1 金币", len(gold_events) == 2
                  and sum(event["amount"] for event in gold_events) == 2
                  and run.state["players"][actor]["temporary_gold"] == 2)
        run.do("FinishAbilities")
        run.do("FinishBuying")
        run.do("FinishUpgrading")
        run.check("TURN_WILL_END 时额外获得 3 经验", run.state["players"][actor]["xp"]
                  == 4 + len(militia))
        run.check("排程已消费", run.state["scheduled_effects"] == [])
    elif case_id == "condition-false":
        run = _Run(case_id, "effect-lab-false", custom_rule=FALSE_RULE)
        run.fixture("加入民兵；手牌中没有疾病或怪物",
                    lambda state: run.add_hand("TS-0001"))
        source = run.first_hand("TS-0001")
        run.do("ChooseAction", action="village")
        options = [option for command in legal_commands(
            run.state, snapshot=run.snapshot, effects=run.effects)
            for option in command.get("options", [])]
        run.check("any 两支均为假，第一条能力不在可发动列表",
                  not any(option["ability_id"] == "TS-0001-A94" for option in options))
        run.reject("ActivateAbility", ability_id="TS-0001-A94",
                   source_instance_id=source)
        run.do("ActivateAbility", ability_id="TS-0001-A95",
               source_instance_id=source)
        run.check("进入 else，并计算 1 + 2 经验", run.state["players"][run.player]["xp"] == 3)
    elif case_id in ("cost-rollback", "cost-gain-discard"):
        run = _Run(case_id, "effect-lab-cost", custom_rule=COST_RULE)
        def arrange(state: dict) -> None:
            run.add_hand("TS-0001")
            run.add_hand("TS-0002")
            run.add_hand("TS-0002")
            if case_id == "cost-gain-discard":
                state["players"][run.player]["xp"] = 3
        run.fixture("加入民兵和两把匕首；成功案例另给 3 经验", arrange)
        source = run.first_hand("TS-0001")
        run.do("ChooseAction", action="village")
        if case_id == "cost-rollback":
            error = run.reject("ActivateAbility", ability_id="TS-0001-A96",
                               source_instance_id=source)
            run.check("错误明确指出费用不足", "cost" in error or "XP" in error)
        else:
            run.do("ActivateAbility", ability_id="TS-0001-A96",
                   source_instance_id=source)
            run.check("支付 2 点经验后剩余 1 点", run.state["players"][run.player]["xp"] == 1)
            run.check("获得应急干粮到弃牌堆", any(
                run.state["instances"][item]["card_id"] == "TS-0003"
                for item in run.state["zones"][f"player:{run.player}:discard"]))
            run.check("两把匕首进入选择候选", len(run.state["pending_choice"]["candidate_instance_ids"]) >= 2)
            chosen = _choice(run, choice_index)
            run.check("所选匕首进入弃牌堆", chosen in run.state["zones"][f"player:{run.player}:discard"])
    else:
        run = _Run(case_id, "effect-lab-battle", custom_rule=BATTLE_RULE)
        run.fixture("在手牌加入民兵，作为合成效果的来源",
                    lambda state: run.add_hand("TS-0001"))
        source = run.first_hand("TS-0001")
        run.do("ChooseAction", action="dungeon")
        run.do("ActivateAbility", ability_id="TS-0001-A97",
               source_instance_id=source)
        run.check("战斗上下文保存攻击 +2 和光照 +1",
                  run.state["battle_context"]["modifiers"] == {"attack": 2, "light": 1})
        targets = next(item["instance_ids"] for item in legal_commands(
            run.state, snapshot=run.snapshot, effects=run.effects)
            if item["type"] == "DeclareBattleTarget")
        result = run.do("DeclareBattleTarget", target_instance_id=targets[0])
        battle = next(item for item in result["events"] if item["kind"] == "battle_resolved")
        run.check("战斗计算轨迹包含两项修正",
                  battle["calculation"]["modifiers"] == {"attack": 2, "light": 1})
    return run.output()
