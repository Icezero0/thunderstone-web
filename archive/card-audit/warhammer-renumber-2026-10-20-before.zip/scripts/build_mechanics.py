"""Freeze individually reviewed continuous card rules against exact source lines."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RULES: list[tuple[str, str, dict]] = []


def add(ids: str, op: str, **params) -> None:
    for ability_id in ids.split():
        RULES.append((ability_id, op, params.copy()))


# Rank, equipment, hand and target conditions were reviewed from these exact
# ability lines, not inferred from the decomposition's generic atom templates.
for number, amount, minimum, maximum in (
    (233, 4, 2, 100), (234, 2, 2, 100), (235, 3, 2, 3), (236, 5, 2, 100),
    (320, 2, 2, 100), (321, 3, 2, 100), (322, 4, 2, 100)):
    add(f"TS-{number:04d}-A01", "rank_bonus", attack=amount,
        minimum=minimum, maximum=maximum)
for number, amount in ((308, 2), (309, 3), (310, 4), (316, 5)):
    add(f"TS-{number:04d}-A02", "rank_bonus", attack=amount, minimum=2, maximum=3)
for number, ability, amount in ((302, 1, 1), (303, 1, 2), (304, 1, 3),
                                 (305, 2, 1), (306, 2, 1), (307, 2, 2)):
    add(f"TS-{number:04d}-A{ability:02d}", "rank_bonus", attack=amount, scale=True)
add("TS-0306-A03", "rank_bonus", light=1, minimum=3, maximum=3)
for number in (302, 303, 304):
    add(f"TS-{number:04d}-A02", "equipment_bonus", weapon_tag="弓", light=1)
add("TS-0234-A02", "equipment_bonus", attack=1, level_scale=True, minimum_rank=2)
add("TS-0245-A03", "equipment_bonus", hero_tag="牧师", light=1)
add("TS-0258-A03", "equipment_bonus", hero_tag="盗贼", attack=1)
add("TS-0260-A02", "equipment_bonus", hero_card_id="TS-0001", attack=2)
add("TS-0262-A02", "equipment_bonus", strength_min=8, attack=4)
add("TS-0265-A02", "equipment_bonus", strength=2)
add("TS-0267-A02", "equipment_bonus", hero_tag="牧师|法师", magic_attack=2)
for number, amount in ((345, -2), (346, -3), (347, -3), (354, 2), (355, 3), (356, 4)):
    add(f"TS-{number:04d}-A02", "equipment_bonus", attack=amount)
for number, amount in ((351, 3), (352, 4), (353, 5)):
    add(f"TS-{number:04d}-A02", "equipment_bonus", weapon_tag="锋利", attack=amount)
for number, amount in ((387, 1), (388, 3), (389, 6)):
    add(f"TS-{number:04d}-A02", "equipment_bonus", weapon_tag="锋利", weight_max=3, attack=amount)
add("TS-0245-A02", "equipment_discount", hero_tag="牧师", amount=3)
add("TS-0265-A03", "extra_equipment", capacity=2)
add("TS-0337-A02 TS-0338-A02 TS-0339-A02", "extra_equipment", capacity=100)

add("TS-0219-A01 TS-0345-A03 TS-0346-A03 TS-0355-A03 TS-0356-A03",
    "hand_bonus", filter={"tag": "佣兵"}, attack=1)
add("TS-0258-A02 TS-0326-A02", "hand_bonus", filter={"tag": "英雄"},
    minimum=3, flat=True, attack=2)
add("TS-0261-A01", "hand_bonus", metric="gold", divisor=2, attack=1)
add("TS-0285-A01", "hand_bonus", metric="gold", divisor=2, magic_attack=1)
add("TS-0320-A02", "hand_bonus", filter={"tag": "物品", "light_min": 1},
    minimum=1, flat=True, light=1)
add("TS-0327-A02", "hand_bonus", filter={"tags_any": ["民兵", "佣兵"]}, attack=1)
add("TS-0328-A02", "hand_bonus", filter={"tags_any": ["民兵", "佣兵"]}, attack=2)
add("TS-0340-A02", "hand_bonus", filter={"name": "方阵士兵"},
    exclude_source=True, attack=1, strength=1)
# The two Phalanx levels share a series; the filter is resolved by series below.
RULES[-1][2]["filter"] = {"subcategory": "方阵"}
for number, amount in ((348, 1), (349, 2), (350, 3)):
    add(f"TS-{number:04d}-A02", "hand_bonus", filter={"magic_min": 1}, absent=True, attack=amount)
add("TS-0383-A03", "hand_bonus", filter={"tag": "物品", "light_min": 1}, absent=True, magic_attack=3)
add("TS-0388-A03", "hand_bonus", filter={"tag": "物品", "light_min": 1}, absent=True, attack=1)
add("TS-0401-A01", "hand_bonus", filter={"gold_present": True}, magic_attack=1)
for number, amount in ((405, 1), (406, 2), (407, 3)):
    add(f"TS-{number:04d}-A02", "hand_bonus", filter={"tag": "法术"}, magic_attack=amount)
add("TS-0451-A02", "hand_bonus", filter={"gold_min": 3}, attack=1)
add("TS-0358-A02", "hero_aura", filter={"card_id": "TS-0001"}, attack=1)
add("TS-0359-A02", "hero_aura", filter={"tags_none": ["战士"]}, attack=2)
for number, amount in ((411, 1), (412, 1), (413, 2)):
    add(f"TS-{number:04d}-A02", "weapon_aura", light=amount,
        **({"attack": amount} if number != 411 else {}))
add("TS-0403-A02 TS-0404-A02", "double_magic")
add("TS-0323-A02 TS-0324-A03", "ignore_darkness", minimum_rank=2, tag="亡灵")
add("TS-0325-A02", "ignore_darkness", minimum_rank=2)
add("TS-0383-A02", "ignore_darkness")
add("TS-0324-A02", "target_bonus", tag="亡灵", magic_attack=2)
add("TS-0375-A02", "target_bonus", gives_disease=True, magic_attack=3)
add("TS-0376-A02", "target_bonus", gives_disease=True, magic_attack=4)
add("TS-0511-A01", "target_bonus", tag="类人生物", attack=1)
add("TS-0317-A01 TS-0318-A01 TS-0319-A01", "rank_restriction", forbidden=[1])

add("TS-0489-A01 TS-0508-A01 TS-0606-A01", "target_restriction", magic_required=True)
add("TS-0487-A01 TS-0604-A01 TS-0656-A01", "target_restriction", half_attack_no_magic=True)
add("TS-0540-A01 TS-0601-A01 TS-0660-A01", "target_restriction", half_magic=True)
add("TS-0605-A01", "target_restriction", half_attack_no_weapon=True)
add("TS-0506-A01", "target_restriction", immune_spells=True)
add("TS-0506-A02", "target_restriction", immune_unarmed=True)
add("TS-0514-A01 TS-0589-A01", "target_restriction", equipped_only=True)
add("TS-0601-A02", "target_restriction", immune_weapon_tag="锋利")
for number, amount in ((657, 4), (658, 5), (659, 6), (660, 7), (661, 8)):
    add(f"TS-{number:04d}-A{'02' if number in (660, 661) else '01'}",
        "target_restriction", strength_min=amount)
add("TS-0537-A01", "target_restriction", exclude_tags=["民兵"])
add("TS-0648-A01", "target_restriction", exclude_tags=["法师"])
add("TS-0649-A01", "target_restriction", exclude_tags=["牧师"])
add("TS-0650-A01", "target_restriction", exclude_tags=["盗贼", "弓箭手"])
add("TS-0651-A01", "target_restriction", exclude_tags=["战士"])
for number, amount in ((561, 3), (562, 3), (563, 5), (564, 4), (565, 5)):
    add(f"TS-{number:04d}-A01", "target_restriction", min_heroes=amount)
add("TS-0664-A02", "target_restriction", no_darkness=True)
add("TS-0505-A01", "target_restriction", forbid_used_spell=True)
add("TS-0509-A01", "target_restriction", forbid_used_spell=True, forbid_equipment=True)
add("TS-0497-A02", "target_restriction", requires_used_spell_or_item=True)
add("TS-0508-A02", "target_restriction", half_no_element=True)

add("TS-0461-A01", "target_health", gold_below_double=5)
add("TS-0462-A01", "target_health", gold_below_double=1)
for number, tag, amount in ((515, "物品", 3), (516, "武器", 4), (518, "英雄", 4),
                            (643, "民兵", 1), (647, "英雄", 2)):
    add(f"TS-{number:04d}-A01", "target_health", filter={"tag": tag}, multiplier=amount)
add("TS-0517-A01", "target_health", metric="gold")
add("TS-0519-A01", "target_health", multiplier=2)
add("TS-0621-A01", "target_health", filter={"tags_any": ["村民", "民兵"]})
add("TS-0623-A01", "target_health", filter={"tags_any": ["村民", "民兵"]}, multiplier=2)
for number, level, amount in ((644, 1, 2), (645, 2, 3), (646, 3, 4)):
    add(f"TS-{number:04d}-A01", "target_health", filter={"tag": "英雄", "level_min": level, "level_max": level},
        multiplier=amount, **({"minimum": 1, "flat": True} if number == 646 else {}))
add("TS-0673-A03", "target_health", filter={"tag": "英雄"}, metric="level_sum")
add("TS-0633-A01", "target_health", other_tag="腐化德鲁伊", multiplier=3)

for number, light in ((496, 1), (497, 2), (498, -2), (499, 3), (680, -1)):
    add(f"TS-{number:04d}-A01", "hall_aura", light=light)
add("TS-0680-A02", "hall_aura", strength=-1)
add("TS-0680-A03", "hall_aura", health=1)
add("TS-0679-A03", "hall_aura", health=1, rank0_only=True)
add("TS-0546-A01", "hall_aura", strength_per_spell=True)
add("TS-0550-A01", "hall_aura", disease_attack=-1)
add("TS-0681-A01", "hall_aura", double_darkness=True)
add("TS-0617-A01", "light_requirement", ranks={"1": 3})
add("TS-0618-A01 TS-0619-A01", "light_requirement", ranks={"1": 5, "2": 4})
add("TS-0620-A01", "light_requirement", ranks={"1": 6, "2": 5, "3": 4})
add("TS-0507-A01", "light_requirement", irreducible=True)
add("TS-0617-A02 TS-0618-A02 TS-0619-A02 TS-0620-A02 TS-0679-A01 TS-0682-A01", "immovable")
add("TS-0717-A01", "disease_strength", amount=-1)
add("TS-0718-A01", "disease_strength", amount=-2, single=True)
add("TS-0538-A01", "hero_aura", strength=-1)
add("TS-0336-A02", "hand_bonus", filter={"tag": "英雄", "level_max": 2}, absent=True, attack=10)
add("TS-0215-A02", "equipment_bonus", hero_tag="牧师", target_tags_any=["末日骑士", "亡灵"], attack=3)
add("TS-0314-A02", "target_bonus", same_family=True, minimum_rank=2, attack=3)
add("TS-0315-A02", "target_bonus", same_family=True, minimum_rank=2, attack=4)
add("TS-0370-A02", "excess_light_magic", amount=1)
add("TS-0371-A02", "excess_light_magic", amount=2)
add("TS-0402-A02", "card_aura", filters_any=[{"tag": "物品"}, {"tag": "法术", "magic_min": 1}], magic_attack=1)
add("TS-0189-A01", "economy", monster_gold_zero=True)
add("TS-0219-A02", "economy", hero_discount=1)
add("TS-0674-A01", "economy", hero_surcharge=2)
add("TS-0720-A01", "economy", all_surcharge=3)
add("TS-0554-A01", "economy", one_purchase=True)
for number in range(520, 530):
    add(f"TS-{number:04d}-A01", "scoring", group="虫群", maximum=5)
for number in range(566, 576):
    add(f"TS-{number:04d}-A01", "scoring", group="怪潮")
add("TS-0708-A01", "scoring", other_stones=2)
add("TS-0713-A01", "scoring", fewest_monsters_bonus=4)


def build() -> bytes:
    draft = json.loads(next((ROOT / "docs").rglob(
        "thunderstone_card_rules_v0.3.2_engine.json")).read_text(encoding="utf-8-sig"))
    abilities = {a["id"]: a for c in draft["cards"] for a in c["abilities"]}
    with (ROOT / "data" / "cards.csv").open(encoding="utf-8-sig", newline="") as handle:
        cards = {c["card_id"]: c for c in csv.DictReader(handle)}
    output = []
    seen = set()
    for ability_id, op, params in RULES:
        card_id = ability_id.split("-A")[0]
        line = abilities[ability_id]["source_line"]
        if line not in cards[card_id]["effect_text"].splitlines() or ability_id in seen:
            raise ValueError(f"stale or duplicate mechanic: {ability_id}")
        seen.add(ability_id)
        output.append({"id": ability_id, "source_card_id": card_id,
                       "source_line": line, "op": op, "params": params})
    return (json.dumps(output, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    path = ROOT / "data" / "effects" / "mechanics.json"
    content = build()
    if args.check:
        if not path.is_file() or path.read_bytes() != content:
            raise ValueError("mechanics.json needs regeneration")
    else:
        path.write_bytes(content)
    print(f"{len(RULES)} reviewed mechanic bindings")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
