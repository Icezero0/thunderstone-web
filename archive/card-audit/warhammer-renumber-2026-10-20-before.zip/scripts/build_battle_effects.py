"""Reviewed monster battle effects and independent hand fixtures."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from build_action_effects import atom, each, mod, select, seq, target


ROOT = Path(__file__).resolve().parents[1]
ABILITIES = []
CASES = []
ANY = {"zone": "subject_hand", "exclude_card_type": "疾病牌", "unmarked": True}
HEROES = {**ANY, "tag": "英雄"}
MILITIA = {**ANY, "card_id": "TS-0001"}


def conditional(query, body):
    return {"op": "if", "condition": {"exists": query}, "then": body}


def destroy(query, count=1):
    if count == 1:
        body = select(query, target("mark_destroy"))
    else:
        body = select(query, each({"zone": "bound", "var": "victims"}, target("mark_destroy")),
                      bind="victims", minimum=count, maximum=count)
        body["allow_shortfall"] = True
    return conditional(query, body)


def add(ability_id, body, *, hand=(), expected=None):
    ABILITIES.append({"id": ability_id, "source_card_id": ability_id.split("-A")[0],
                      "kind": "triggered", "source_zone": "battle_target", "event": "BATTLE_BEFORE_OUTCOME",
                      "usage": "once_per_event", "conditions": [], "body": body})
    CASES.append({"ability_id": ability_id, "hand": list(hand), "expected": expected or {}})


for ability_id in ("TS-0459-A01", "TS-0516-A02", "TS-0598-A01", "TS-0626-A01"):
    add(ability_id, destroy({**ANY, "tag": "武器"}), hand=("TS-0002",), expected={"destroyed": ["TS-0002"]})
for ability_id in ("TS-0467-A02", "TS-0475-A01", "TS-0491-A02"):
    add(ability_id, destroy({**ANY, "tag": "法术"}), hand=("TS-0274",), expected={"destroyed": ["TS-0274"]})
for ability_id in ("TS-0486-A01", "TS-0488-A01", "TS-0553-A02", "TS-0597-A01",
                   "TS-0668-A01", "TS-0656-A02", "TS-0649-A02", "TS-0650-A02"):
    add(ability_id, destroy(MILITIA), hand=("TS-0001",), expected={"destroyed": ["TS-0001"]})
for ability_id in ("TS-0512-A01",):
    add(ability_id, destroy({**ANY, "tag": "佣兵"}), hand=("TS-0219",), expected={"destroyed": ["TS-0219"]})
for ability_id in ("TS-0545-A02", "TS-0590-A02", "TS-0591-A02", "TS-0648-A02"):
    add(ability_id, destroy({**HEROES, "tag": "战士"}), hand=("TS-0351",), expected={"destroyed": ["TS-0351"]})
add("TS-0468-A02", destroy({**HEROES, "tags_any": ["牧师", "法师"]}),
    hand=("TS-0401",), expected={"destroyed": ["TS-0401"]})
add("TS-0492-A02", destroy({**ANY, "tag": "魔法", "tags_any": ["武器", "物品"]}),
    hand=("TS-0267",), expected={"destroyed": ["TS-0267"]})
add("TS-0460-A01", destroy({**ANY, "card_type": "村庄牌", "max_by": "gold"}),
    hand=("TS-0227", "TS-0237"), expected={"destroyed": ["TS-0227"]})
add("TS-0496-A02", destroy(ANY), hand=("TS-0004",), expected={"destroyed": ["TS-0004"]})
add("TS-0515-A02", destroy({**ANY, "tag": "物品"}), hand=("TS-0003",), expected={"destroyed": ["TS-0003"]})
add("TS-0517-A02", destroy({**ANY, "gold_present": True}), hand=("TS-0003",), expected={"destroyed": ["TS-0003"]})
for ability_id in ("TS-0518-A02", "TS-0654-A01", "TS-0653-A02"):
    add(ability_id, destroy(HEROES), hand=("TS-0302",), expected={"destroyed": ["TS-0302"]})
add("TS-0599-A01", destroy({**ANY, "tag": "食物"}), hand=("TS-0004",), expected={"destroyed": ["TS-0004"]})
add("TS-0605-A02", destroy({**HEROES, "tag": "牧师"}), hand=("TS-0435",), expected={"destroyed": ["TS-0435"]})
add("TS-0637-A01", destroy({**HEROES, "exclude_card_id": "TS-0001"}), hand=("TS-0302",), expected={"destroyed": ["TS-0302"]})
add("TS-0642-A01", destroy({**ANY, "tag": "物品"}), hand=("TS-0003",), expected={"destroyed": ["TS-0003"]})
add("TS-0643-A02", destroy({**ANY, "tags_any": ["武器", "法术"]}), hand=("TS-0002",), expected={"destroyed": ["TS-0002"]})
add("TS-0645-A02", destroy({**HEROES, "level_min": 1, "level_max": 1}), hand=("TS-0302",), expected={"destroyed": ["TS-0302"]})
add("TS-0646-A02", destroy({**HEROES, "level_min": 2, "level_max": 2}), hand=("TS-0303",), expected={"destroyed": ["TS-0303"]})
add("TS-0647-A02", destroy({**ANY, "light_min": 1}), hand=("TS-0003",), expected={"destroyed": ["TS-0003"]})
add("TS-0651-A02", destroy({**HEROES, "tag": "法师"}), hand=("TS-0401",), expected={"destroyed": ["TS-0401"]})
for ability_id in ("TS-0556-A01", "TS-0557-A01"):
    add(ability_id, destroy({**HEROES, "min_by": "strength"}), hand=("TS-0001", "TS-0304"),
        expected={"destroyed": ["TS-0001"]})
add("TS-0672-A02", destroy({**HEROES, "max_by": "strength"}), hand=("TS-0001", "TS-0304"), expected={"destroyed": ["TS-0304"]})
add("TS-0615-A02", destroy({**HEROES, "max_by": "attack"}), hand=("TS-0001", "TS-0304"), expected={"destroyed": ["TS-0304"]})
add("TS-0558-A01", destroy({**HEROES, "strength_max": 4}, 2), hand=("TS-0001", "TS-0001", "TS-0304"),
    expected={"destroyed": ["TS-0001", "TS-0001"]})
add("TS-0559-A01", seq(destroy({**HEROES, "strength_max": 5}, 2), destroy({**ANY, "tag": "武器", "min_by": "weight"})),
    hand=("TS-0001", "TS-0001", "TS-0002"), expected={"destroyed": ["TS-0001", "TS-0001", "TS-0002"]})
for ability_id, strength, attack in (("TS-0469-A02", -4, -1), ("TS-0478-A01", -2, 0),
                                    ("TS-0487-A02", -2, 0), ("TS-0489-A02", -4, 0),
                                    ("TS-0493-A02", -3, 0), ("TS-0588-A01", -2, -1),
                                    ("TS-0590-A01", -2, 0)):
    add(ability_id, each(HEROES, seq(mod("strength", strength), mod("attack", attack))),
        hand=("TS-0304",), expected={"modified": {"strength": strength, "attack": attack}})
for ability_id in ("TS-0485-A01", "TS-0533-A01"):
    q = {**HEROES, "participating": True}
    add(ability_id, conditional(q, select(q, target("exclude_combat"))), hand=("TS-0302",), expected={"excluded": 1})
for ability_id, count in (("TS-0534-A01", 1), ("TS-0535-A01", 2)):
    q = {**HEROES, "participating": True}
    if count == 1:
        body = select(q, seq(target("exclude_combat"), target("mark_destroy")))
    else:
        body = select(q, each({"zone": "bound", "var": "victims"},
                              seq(target("exclude_combat"), target("mark_destroy"))), bind="victims", minimum=2, maximum=2)
        body["allow_shortfall"] = True
    add(ability_id, conditional(q, body), hand=("TS-0302", "TS-0303"), expected={"excluded": count, "destroy_count": count})
for ability_id in ("TS-0613-A02", "TS-0669-A01"):
    add(ability_id, each({**HEROES, "tag": "弓箭手"}, target("mark_destroy")),
        hand=("TS-0302", "TS-0303"), expected={"destroyed": ["TS-0302", "TS-0303"]})
add("TS-0644-A02", each(MILITIA, target("mark_destroy")), hand=("TS-0001", "TS-0001"), expected={"destroyed": ["TS-0001", "TS-0001"]})
add("TS-0606-A03", each({**HEROES, "tags_any": ["牧师", "法师"]}, target("mark_destroy")),
    hand=("TS-0401", "TS-0435"), expected={"destroyed": ["TS-0401", "TS-0435"]})
add("TS-0464-A02", each({**ANY, "duplicate_names": True}, target("mark_destroy")),
    hand=("TS-0001", "TS-0001", "TS-0004"), expected={"destroyed": ["TS-0001", "TS-0001"]})
for ability_id, q, amount in (("TS-0638-A01", {**ANY, "tag": "物品", "light_min": 1}, 1),
                             ("TS-0639-A01", {**ANY, "card_id": "TS-0002"}, 4),
                             ("TS-0641-A01", MILITIA, 2),
                             ("TS-0555-A02", {**ANY, "tag": "武器"}, -1)):
    hand = ("TS-0003",) if ability_id == "TS-0638-A01" else ("TS-0001",) if ability_id == "TS-0641-A01" else ("TS-0002", "TS-0001")
    add(ability_id, each(q, mod("attack", amount)), hand=hand, expected={"modified": {"attack": amount}})
    if ability_id in ("TS-0639-A01", "TS-0555-A02"):
        CASES[-1]["equipment"] = ["TS-0001", "TS-0002"]
for ability_id in ("TS-0479-A01", "TS-0550-A02"):
    add(ability_id, atom("gain_disease", 2), expected={"diseases": 2})
add("TS-0484-A02", seq(atom("gain_disease", 2), {"op": "for_players", "scope": "others", "body": atom("gain_disease", 1)}),
    expected={"diseases": 2, "other_diseases": 1})
add("TS-0498-A02", {"op": "for_players", "scope": "all", "body": atom("gain_disease", 1)}, expected={"diseases": 1, "other_diseases": 1})
add("TS-0539-A01", seq(atom("gain_disease", {"count": MILITIA}), each(MILITIA, target("mark_destroy"))),
    hand=("TS-0001", "TS-0001"), expected={"diseases": 2, "destroyed": ["TS-0001", "TS-0001"]})
add("TS-0540-A02", atom("gain_disease", {"count": {**HEROES, "tags_any": ["民兵", "战士"]}}),
    hand=("TS-0001", "TS-0351"), expected={"diseases": 2})
q = {**ANY, "tag": "食物"}
add("TS-0607-A01", seq(each(q, target("mark_destroy")), atom("gain_disease", {"count": {"zone": "subject_hand", "tag": "食物"}})),
    hand=("TS-0004", "TS-0004"), expected={"diseases": 2, "destroyed": ["TS-0004", "TS-0004"]})
q = {**ANY, "tag": "物品", "light_min": 1}
add("TS-0608-A01", conditional(q, select(q, seq(target("mark_destroy"), atom("gain_disease", 1)))),
    hand=("TS-0003",), expected={"diseases": 1, "destroyed": ["TS-0003"]})
q = MILITIA
body = select(q, each({"zone": "bound", "var": "victims"}, seq(target("mark_destroy"), atom("gain_disease", 1))), bind="victims", minimum=2, maximum=2)
body["allow_shortfall"] = True
add("TS-0609-A01", conditional(q, body), hand=("TS-0001", "TS-0001"), expected={"diseases": 2, "destroyed": ["TS-0001", "TS-0001"]})
for ability_id, q, field, hand in (("TS-0610-A01", {**HEROES, "tag": "战士"}, "level", ("TS-0352",)),
                                  ("TS-0611-A01", {**ANY, "subcategory": "怪物"}, "xp_reward", ("TS-0476",))):
    add(ability_id, conditional(q, select(q, seq(target("mark_destroy"), atom("gain_disease", {"stat": {"var": "chosen", "field": field}})))),
        hand=hand, expected={"diseases_from_stat": {"card_id": hand[0], "field": field}, "destroyed": list(hand)})
add("TS-0612-A01", {"op": "if", "condition": {"exists": {"zone": "subject_hand", "card_type": "疾病牌"}},
                    "then": atom("gain_disease", 2), "else": atom("gain_disease", 1)},
    hand=("TS-0714",), expected={"diseases": 2})
add("TS-0483-A01", {"op": "repeat", "times": {"min": [100, {"count": {"zone": "subject_hand", "card_type": "疾病牌"}}]},
                    "limit": 100, "body": destroy(ANY)}, hand=("TS-0714", "TS-0004"), expected={"destroyed": ["TS-0004"]})

add("TS-0553-A03", {"op": "for_players", "scope": "all", "body": atom("lose_xp")}, expected={"xp_loss_each": 1})
add("TS-0504-A02", {"op": "for_players", "scope": "all", "body": destroy({**ANY, "subcategory": "怪物"})},
    hand=("TS-0476",), expected={"destroy_count_each": 1})
for id in ("TS-0635-A01", "TS-0636-A01"):
    add(id, {"op": "for_players", "scope": "all", "body": atom("gain_disease")}, expected={"diseases": 1, "other_diseases": 1})
add("TS-0635-A03", destroy({**HEROES, "tag": "牧师"}), hand=("TS-0435",), expected={"destroyed": ["TS-0435"]})
add("TS-0636-A03", destroy({**HEROES, "level_min": 1}), hand=("TS-0302",), expected={"destroyed": ["TS-0302"]})
add("TS-0507-A02", each({**HEROES, "equipped": False, "magic_max": 0}, target("mark_destroy")),
    hand=("TS-0001", "TS-0323"), expected={"destroyed": ["TS-0001"]})
add("TS-0600-A01", {"op": "if", "condition": {"not": {"exists": {**HEROES, "equipped": True}}},
    "then": destroy(HEROES)}, hand=("TS-0001",), expected={"destroyed": ["TS-0001"]})
add("TS-0629-A01", each({**HEROES, "equipped": True}, mod("attack", 1)),
    hand=("TS-0001", "TS-0002"), expected={"modified": {"attack": 1}})
CASES[-1]["equipment"] = ["TS-0001", "TS-0002"]


def build():
    with (ROOT / "data" / "effects" / "battle-contracts.csv").open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            add(row["ability_id"], atom("gain_disease", 1), expected={"diseases": 1})
    draft = json.loads(next((ROOT / "docs").rglob("thunderstone_card_rules_v0.3.2_engine.json")).read_text(encoding="utf-8-sig"))
    lines = {a["id"]: a["source_line"] for c in draft["cards"] for a in c["abilities"]}
    with (ROOT / "data" / "cards.csv").open(encoding="utf-8-sig", newline="") as handle:
        cards = {c["card_id"]: c for c in csv.DictReader(handle)}
    for ability, case in zip(ABILITIES, CASES):
        line = lines[ability["id"]]
        if line not in cards[ability["source_card_id"]]["effect_text"].splitlines():
            raise ValueError(f"stale card line: {ability['id']}")
        case["source_line"] = line
    return {"battle-reviewed.json": {"schema_version": "thunderstone.effects/1", "abilities": ABILITIES},
            "battle-contracts.json": CASES}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    for name, artifact in build().items():
        content = (json.dumps(artifact, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        path = ROOT / "data" / "effects" / name
        if args.check:
            if not path.is_file() or path.read_bytes() != content:
                raise ValueError(f"stale artifact: {name}")
        else:
            path.write_bytes(content)
    print(f"{len(ABILITIES)} reviewed battle bindings and card scenarios")


if __name__ == "__main__":
    main()
