# 卡牌能力编译与结算

当前可执行子集及 JSON 格式见 [实现说明](ability-runtime-implementation.md)。参考 JSON 仍是设计草案；目前只有通过独立规则包审核的 3 条能力进入解释器，其余能力状态见 [覆盖清单](../../data/effects/coverage.csv)。

参考 JSON 含 722 张牌与 964 条能力，词典覆盖触发、条件、效果原子、控制流和选择器。但它的 `implementation_maturity` 为 `AST_DESIGN_DRAFT_NOT_DIRECTLY_EXECUTABLE`：799 条仍是缺少完整绑定的通用模板，163 条是不同程度的逐卡草案，另外 2 条仅引用系统规则。本文件规定从草案到 Python 可执行规则的门槛。

## 1. 能力定义的边界

```text
AbilityDefinition
  ability_id, source_card_id, display_source_line
  trigger_event, valid_zones, mandatory_or_optional
  conditions: typed predicates
  target_query: typed instance query and choice actor
  body: typed EffectNode tree
  duration / usage_limit / priority_basis
  source_reference, compiled_ruleset_version
```

中文 `source_line` 用于展示与追溯，不是程序。`prefix` 例如“村庄”“地下城”“战斗”“凯旋”“突破”只提供触发线索；无前缀效果还需要由牌型与有效区域确定它是英雄攻击、怪物战斗特性、手牌战利品还是环境全局效果。`trigger.event=PASSIVE_OR_CONTEXTUAL_EVENT` 等泛化值不能直接注册为所有场景的监听器。

CSV 的 `effect_text` 是玩家显示来源，规则 JSON 是能力草案。`TS-0717`、`TS-0718` 两张疾病牌的 JSON 提示文字与 CSV 仍不一致；运行规则按已确认的系统规则处理，不能因为显示文本不同而额外触发一次摧毁。

## 2. 有类型的节点

| 层 | 示例 | 编译时必须确定 |
| --- | --- | --- |
| 事件与有效范围 | `ACTION_ENTERED`、`TURN_WILL_END`、`TURN_ENDED`、`HALL_ENTER` | 事件数据结构、来源牌有效区域、是否强制、频率；回合时点见[回合流程](04-turn-flow.md) |
| 条件 | 阶层比较、手牌数量、设置生效 | 输入属性、运算符、缺失值行为 |
| 选择器 | `FILTER`、`ARGMAX`、`UP_TO`、`PLAYER_CHOICE` | 查询区域、标签/类型过滤、数量、并列时选择者 |
| 控制流 | `SEQUENCE`、`IF`、`COST_GATE`、`FOR_EACH`、`REPEAT_UNTIL`、`SCHEDULE` | 子节点顺序、支付失败路径、终止条件、恢复点 |
| 效果原子 | `A_DRAW`、`A_DESTROY`、`A_MOD_ATTACK`、`A_HALL_MOVE` | 目标、数量表达式、作用时点、事件结果 |

可执行 AST 使用受限的已注册节点和参数类型。参数只能引用状态字段、事件字段、常量或获准的表达式操作；不能对 JSON/CSV 的文本执行 Python 代码、`eval` 或不受控的函数调用。少数无法自然表示的卡牌可以注册专门的 Python 处理器，但仍以能力 ID 标识并接受相同的事件、版本和测试约束。

## 3. 编译管线

1. **结构检查**：确认 JSON `schema_version`、唯一能力 ID、来源 `card_id`、字典中的原子/控制节点引用、AST 节点名称和字段形状。实际草案位于 `cards[].abilities[].ast`。
2. **来源对照**：匹配 CSV 的名称、分类、标签、数值与能力文本，列出已知差异；不因工作簿旧路径或 JSON 旧图片路径重写 CSV。
3. **语义绑定**：将 `trigger`、`conditions`、`target_queries` 与 `ast` 合成能力。`flow_nodes`、`effect_atom_ids`、`clauses` 用于检查拆解是否遗漏，不可替代 AST 的实际语义。
4. **参数完善**：`source_excerpt`、`amount_hint` 只是抽取提示。必须绑定真实目标、数量、作用域、有效期、支付规则与选择者。例如“每有 1 张怪物，抽 2 张”需要 `2 * 当前合格怪物数`，不是固定抽 2。
5. **类型和可执行性验证**：查询输出类型要符合原子输入；强制目标必须存在或有定义好的空集合行为；`REPEAT_UNTIL` 有合法终止路径；替代事件不能无界自触发。
6. **场景测试和发布**：正常、无目标、资源不足、并列目标、区域变化和来源离场等情况按需覆盖。通过后才标记 `READY` 并允许进入对应牌池。

建议为每条能力保存 `DRAFT`、`BLOCKED_SCHEMA`、`BLOCKED_BINDING`、`COMPILED_UNTESTED`、`READY`、`RULE_REFERENCE` 等状态及具体原因。`is_executable_as_card_ability=true` 只说明应作为牌能力处理，**不自动等于 `READY`**。任一可能选出的卡仍有阻塞能力时，组局应在开始前失败或选择经过审核的受限牌池。

## 4. 事件结算与选择

一次指令结算使用显式事件队列和继续帧：

```text
Command -> 验证合法行动 -> 提议事件
        -> 适用替代/阻止规则
        -> 查询有效来源与条件
        -> 按有依据的顺序执行效果树
        -> 派生事件 / PendingChoice / 终局
```

事件记录至少有 `event_id`、类型、来源能力/系统规则、行为玩家、涉及实例、进入前后的关键区域或数值、可见性。替代规则处理的是“将要发生”的事件；普通触发监听的是实际发生的事件，两者不能混为一个回调。持续效果从当前有效来源和期限导出，来源离场时失效；一次性效果改变状态后不会因为再次查询而重复叠加。

同事件有多个效果时，应先按规则确定强制/可选、控制者与顺序。规则没有给出固定顺序而要求玩家裁定时产生 `PendingChoice`；不要任意按卡牌 ID 排序来假装规则已明确。系统应检测无进展循环，但不能因为一次迭代没有命中目标就终止本可继续的陷阱循环。

选择会暂停效果树。`PendingChoice` 保存执行帧、合法候选实例、可选数量、选择者以及对其他玩家能公开的提示。下一条 `ResolveChoice` 指令重新校验候选仍合法，再继续执行；期间不能接受无关玩家操作。每条指令的状态和事件应原子提交。

## 5. 代价、次数与延迟效果

`COST_GATE` 先验证可支付及玩家是否选择发动。代价成功支付才执行收益；无法支付时不得部分获得收益。若支付或收益内部需要玩家选择，运行时先保存选择，再按节点定义的顺序完成状态变化。重复能力每次都重新支付。普通能力按来源实体和能力 ID 记录本回合使用次数。

`SCHEDULE` 登记未来事件，如回合末摧毁；`REGISTER_TRIGGER` 登记指定区域或设置生效期间的监听；`REPLACE_EVENT` 改变原事件去向。需要记录来源、有效期限、唯一结算键和注销条件。系统规则 `BASE_STRENGTH_ZERO_DESTRUCTION` 在战斗中第一次检测到某英雄力量 `<= 0` 时登记一次回合末摧毁；后续恢复不撤销，重复检测不产生第二次摧毁。

## 6. 具体能力示例

**`TS-0437-A02` 神圣先知**：玩家在村庄或地下城可选择发动；必须从自己当前手牌中选一张疾病并摧毁，成功支付后抽 2 张。无疾病时不可发动；选择跳过时不支付也不抽。JSON 已有 `CHOICE` 与 `COST_GATE` 草案，可作为首批编译样例。

**`TS-0437-A03` 同卡另一能力**：文本为“手牌中每有 1 张怪物牌，抽 2 张牌”，草案列出 `COUNT_RESULT`，但 AST 只固定抽 2 张。必须绑定计数查询和倍数表达式后才能标记可执行。

**`TS-0193-A02` 荆棘森林**：环境设置生效后，玩家完成休整或访问村庄时，在非空村庄供应堆中找堆顶购买价最高者；并列时由当前玩家选一堆，再摧毁该堆顶一张。需要持续触发、`ARGMAX`、并列选择与堆顶重新确认，不能只在开局执行一次。

**`TS-0717-A02` / `TS-0718-A02`**：两条 `RULE_REFERENCE` 指向全局零力量规则，`execute_here=false`。它们不会各自生成一个 `A_DESTROY`。

**`TS-0199` 放逐仪式**：设置阶段改变雷霆之石、末日之心及终局规则。它是一个场景配置和事件替代的组合，不能把其每行文字当作普通战斗阶段的即时原子。

## 7. 计分与可解释结果

动态 `*` 胜利点由终局计分能力在终局快照上求值。计分输出应包含每张牌实例的固定或动态分值、公式所用的目标集合、总分及同分裁决依据。战斗的 `CalculationTrace` 同理保留各来源的攻击、光照、免疫、倍数和最终比较结果。这些解释材料供客户端展示和错误排查，不由客户端重新决定结果。
