# Executable ability runtime

## Sources and release boundary

`docs/游戏引擎设计参考/thunderstone_card_rules_v0.3.2_engine.json` is a decomposition draft of 964 ability lines. The engine does not execute its generic AST. The reviewed `classic-v1.json`, `simple-reviewed.json`, `action-reviewed.json`, `battle-reviewed.json` and `event-reviewed.json` contain 348 fully bound abilities. `mechanics.json` contains 190 continuous rule bindings. Each binding names a stable ability ID, card source and its applicable zone or rule hook. Offline generators check the exact source line against the catalog. Runtime dispatch uses these bindings rather than parsing arbitrary Chinese text.

The JSON has no embedded Python. Compilation rejects unknown keys, unknown operations, unsupported expressions, invalid source IDs, duplicate IDs, unbounded loops and missing bindings. The runtime receives the same `CatalogSnapshot` as setup/turn code; it does not open SQLite. It uses the game state's event, instance and RNG sequences, and one command either returns a complete new state or raises without changing its input.

## Executable JSON shape

```json
{
  "schema_version": "thunderstone.effects/1",
  "abilities": [
    {
      "id": "TS-0437-A02",
      "source_card_id": "TS-0437",
      "kind": "activated",
      "actions": ["village", "dungeon"],
      "source_zone": "active_hand",
      "usage": "once_per_turn",
      "conditions": [],
      "body": {
        "op": "select", "query": {"zone": "active_hand", "card_type": "疾病牌"},
        "bind": "disease", "min": 1, "max": 1,
        "then": {"op": "cost_gate",
          "cost": {"op": "destroy", "target": {"var": "disease"}},
          "then": {"op": "draw", "count": 2}}
      }
    }
  ]
}
```

An activated ability is submitted as `ActivateAbility` with `source_instance_id` and `ability_id`. Activated sources can be in `active_hand` or `active_control` (treasures). Trigger sources can also be `settings`, `battle_target`, `hall` or `event_source`. This is essential for monsters: an ordinary hand attack/light line does not apply from the hall; a battle ability does not trigger from another copy held as a trophy. Source identity is checked again when a pending choice resumes.

## Typed parts

| Part | First implementation | Later extension boundary |
| --- | --- | --- |
| Expressions | bounded integers and arithmetic; count/sum/maximum; card stats; resources; bound values; typed event rank/price | expressions and nested queries require in-scope variables |
| Conditions | `all`, `any`, `not`, `compare`, `exists`, `action_in`, `setting_active` | no evaluation of free text |
| Queries | active/subject hand and discard; controlled treasures; supply tops; bound reveals; hall/rank; event source; just-defeated monster; typed filters and extrema | hero queries include hero cards and village/basic cards tagged hero |
| Flow | sequence, condition, optional/multiple selection, cost, per-card/per-player loops, bounded repeat, numeric binding, reveal, draw-and-bind, scheduling, effect purchase | choices serialize frames; per-player effects select the correct responding player |
| Atoms/hooks | resources, disease, card movement/destruction, per-card modifiers, deferred battle destruction, supply destruction, hall relocation, random discard, reveal cycles, next-hand bonus | copying, replacements, borrowing and several scenario rules remain pending |

The interpreter executes depth-first. A `select` with one legal candidate binds automatically; with several candidates it stores `pending_choice` and serializable continuation frames. `ResolveChoice` must come from the named player, choose current candidates and satisfy count bounds. Other commands are rejected while a choice is pending. A failed `cost_gate` never runs its benefit. `source` is a reserved binding for the ability's own instance. Abilities can be once per turn or repeatable; the once per turn limit is stored per source instance and ability and reset during turn cleanup. The canonical JSON hash is stored as `GameState.effects_version`; a changed ruleset cannot silently continue an old state.

`schedule` supports `TURN_WILL_END`, `BATTLE_AFTER_OUTCOME`, `HAND_REFILL_COMPLETE` and the same player's next `TURN_START`. An opponent's turn does not consume the schedule. Reviewed battle lines resolve in their card order. Other simultaneous triggers can request `ResolveEffectOrder`; the selected order must contain each offered effect once. `ResolveChoice` accepts `instance_ids` for multiple/optional selections. `ResolveEffectPurchase` selects an affordable offered card or skips the purchase.

## Initial verified bindings

| Ability | Binding | Test focus |
| --- | --- | --- |
| `TS-0437-A02` | choose and destroy one disease in the active hand as cost, then draw two; village or dungeon | no disease, several diseases, pending choice and replay |
| `TS-0437-A03` | draw twice the number of monster cards currently in hand | zero, one and multiple monsters; no fixed `2` shortcut |
| `TS-0193-A02` | after village or rest, destroy the highest priced nonempty village supply top; active player breaks a tie | empty supply, unique maximum, tie, source setting inactive |

The second reviewed JSON adds exact draw, XP, extra purchase, self destruction for gold, disease destruction for draw, militia destruction for XP, and temporary attack/magic attack abilities. Separately, the combat baseline reads exact unconditional attack/magic attack/light lines when the corresponding structured field is blank. Target rules cover immunity to magic attack and magic attack only. Battle rules give one disease when a monster with the exact printed line is fought; the current weighted disease supply determines its card ID. Environment rules cover the printed light penalties for `TS-0193` and `TS-0194`. These direct rules have one frozen source line contract per card.

Continuous combat rules recalculate rank, equipment, strength, hand conditions, hall auras, light and target restrictions. Ordinary rank 1/2/3 requires 1/2/3 light; every missing light costs 2 attack. Thornwood Forest requires 1 light at ordinary ranks, while rank 0 stays exempt. Disease attack penalties apply to one positive attack type, with `AssignDiseasePenalty` allowing an explicit allocation. Fatigue affects one hero; `AssignStrengthPenalty` changes that allocation. Zero strength reached in battle creates one sticky turn-end destruction mark, even if strength later recovers.

The generated [ability report](../../data/effects/coverage.csv) and [card report](../../data/effects/card-coverage.csv) track coverage. Current statuses: 348 `READY`, 190 `MECHANIC_READY`, 215 `PRINTED_BASELINE`, 19 `TARGET_RULE`, 6 `SETUP_READY`, 2 `ENV_RULE`, 13 `SYSTEM_RULE`, 10 `SYSTEM_RUNTIME_ONLY`, 90 `DRAFT_TEMPLATE`, 71 `DRAFT_CARD_SPECIFIC`. Of 520 effect cards, 386 are complete, 77 partial and 57 pending. `SYSTEM_RUNTIME_ONLY` currently covers the Treefolk's temporary ranks during play; their initial setup timing awaits a user ruling and is not counted complete. The remaining backlog includes replacements, borrowing/copying, several setup/supply operations, and special scenario endings.

Verify generated files with `--check` on `build_simple_effects.py`, `build_action_effects.py`, `build_battle_effects.py`, `build_event_effects.py` and `build_mechanics.py`. Regenerate reports with `scripts/audit_effects.py --output data/effects/coverage.csv --card-output data/effects/card-coverage.csv`. `--require-complete` deliberately fails while any card remains unfinished.

`tests/test_card_effects.py` creates a stable `test_effect_TS_XXXX` entry for every one of the 520 effect cards. A card entry executes its reviewed behaviors when all its lines are covered; incomplete cards are explicitly **skipped** with their pending ability IDs. Separate card ID named tests run each reviewed printed, activated, target and battle contract even when the rest of that card is still pending. The manifest test checks that contracts still match exact card lines. Setup and environment tests cover their reviewed card IDs. The coverage report is deliberately stricter than test count: a card is complete only when **every** decomposed ability line is covered. A skipped card entry is a backlog marker, not a successful effect test.

## Turn integration

`engine/turn/workflow.py` serializes event dispatch, hall refill, effect continuation and turn cleanup. Timings include dungeon/village entry, equipment, purchases, upgrades, battle before/after outcome, monster defeat, hall reveal, breach, traps, hand refill and turn start/end. If refill reveals a trap, the original ability stack stays in the workflow while the trap runs; after its choices complete, the original ability continues. The previous parallel implementations of combat and hall refill were removed.

`engine/effects/purchase.py` gives each spoils offer its own allowance from the current surviving hand, rather than sharing the village gold pool. `engine/scoring.py` handles printed VP and reviewed insect/horde/stone scoring at standard settlement. Banishing Ritual play remains rejected until its special victory/elimination rules are implemented. Flying Spire's unclaimed-stone boundary is also awaiting a ruling. The backend submits commands and persists states; these calculations stay independent of network and database code.
