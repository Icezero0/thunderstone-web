# Effect runtime verification lab

This temporary local page exercises the executable JSON effect interpreter through the public setup and turn APIs. It is a developer probe, not a playable match client. Each request creates a fresh deterministic game in memory, applies an explicitly described fixture, submits commands, and returns a step trace. No trace or game state is stored in SQLite.

## Open the page

From the project root, start the existing local preview yourself:

```powershell
.\.venv\Scripts\python.exe scripts\run_config_panel.py --host 127.0.0.1 --port 8765
```

Open `http://127.0.0.1:8765/effect-lab`. Select a case, move through the timeline, and inspect the command, state before and after, actual DSL node path, emitted events, available next commands, assertions, and compiled JSON ability. At a pending choice, clicking a candidate replays the same seeded case with that candidate selected. The page marks synthetic DSL examples separately from reviewed card abilities.

## Case matrix

| Case | Source | Main contract |
| --- | --- | --- |
| `trophy-versus-battle` | Reviewed `TS-0603` | Two hand trophies give magic attack +2; the target in the hall gives no hand attack and triggers disease once. |
| `refill-trap-resume` | Reviewed `TS-0275`, `TS-0688` | Returning a monster reveals a trap; the trap choice finishes before the original ability requests its destruction cost and draws. |
| `disease-choice` | Reviewed `TS-0437-A02` | Two legal disease targets pause execution; chosen disease is removed; draw two; activation is once per turn. |
| `monster-count` | Reviewed `TS-0437-A03` | Query counts monster cards in hand and evaluates `2 × count` before drawing. |
| `thornwood-tie` | Reviewed `TS-0193-A02` | Action-exit trigger selects among tied maximum-price village supply tops; cleanup waits for the choice. |
| `thornwood-unique` | Reviewed `TS-0193-A02` | A single maximum-price candidate resolves automatically and the turn passes. |
| `condition-schedule` | Synthetic JSON | Conditions, branch, card loop, bounded repeat, and `TURN_WILL_END` scheduling. |
| `condition-false` | Synthetic JSON | False `any` condition prevents activation; a second ability enters `else` and evaluates addition. |
| `cost-rollback` | Synthetic JSON | An unaffordable XP cost rejects the complete command without changing its input state. |
| `cost-gain-discard` | Synthetic JSON | Pay XP, gain a basic card, pause for dagger selection, and discard the chosen card. |
| `battle-modifiers` | Synthetic JSON | Attack and light modifiers reach the battle calculation trace. |

The synthetic abilities use `TS-0001` as a source solely to drive the interpreter. They are not entries in the reviewed effect JSON and do not claim that militia has these powers. The 11 lab examples illustrate selected behaviors. Complete per-card verification is tracked separately in `data/effects/card-coverage.csv` and `tests/test_card_effects.py`.

The runner lives in `devtools/effect_lab.py`, the page in `web/effect_lab.*`, and the read-only preview routes in `backend/app/api/resources.py`. Each trace includes its fixed seed, rule version, input command sequence, state projections, actual interpreter decisions, engine events, and explicit checks. `apply_command(..., trace_effects=True)` returns these debug decisions as `effect_trace`; they do not enter game state or the authoritative event log. Unit tests in `tests/test_effect_lab.py` run every case, alternative choices, rollback behavior, and the HTTP preview routes without starting a server.

```powershell
.\.venv\Scripts\python.exe -m unittest tests.test_effect_lab -v
```
