"""Public-command effect scenarios and their temporary visualization endpoint."""

from __future__ import annotations

import unittest

from fastapi.testclient import TestClient

from backend.app.main import app
from devtools.effect_lab import CASES, run_case
from engine.setup import start_game
from engine.turn import apply_command
from tests.test_setup_engine import request


class EffectLabTests(unittest.TestCase):
    def test_every_scenario_has_a_reproducible_passing_trace(self) -> None:
        for case in CASES:
            with self.subTest(case=case["id"]):
                result = run_case(case["id"])
                self.assertTrue(result["passed"], result["checks"])
                self.assertTrue(result["steps"])
                self.assertTrue(result["abilities"])
                self.assertTrue(all("before" in step and "after" in step
                                    for step in result["steps"]))
                commands = [step for step in result["steps"]
                            if step["type"] == "command"]
                self.assertTrue(commands)
                self.assertTrue(any(step["events"] for step in commands))
        first = run_case("disease-choice")
        self.assertEqual(first, run_case("disease-choice"))

    def test_choice_variants_resolve_different_instances(self) -> None:
        for case_id in ("disease-choice", "thornwood-tie", "cost-gain-discard"):
            with self.subTest(case=case_id):
                left = run_case(case_id, choice_index=0)
                right = run_case(case_id, choice_index=1)
                self.assertTrue(left["passed"] and right["passed"])
                selected = lambda result: next(
                    event["selected_instance_id"]
                    for step in result["steps"] for event in step["events"]
                    if event["kind"] == "effect_choice_resolved")
                self.assertNotEqual(selected(left), selected(right))

    def test_invalid_choice_and_rejected_cost(self) -> None:
        with self.assertRaises(ValueError):
            run_case("disease-choice", choice_index=99)
        with self.assertRaises(KeyError):
            run_case("unknown")
        trace = run_case("cost-rollback")
        rejected = next(step for step in trace["steps"] if step["type"] == "rejected")
        self.assertEqual(rejected["before"], rejected["after"])
        self.assertEqual(rejected["events"], [])
        self.assertTrue(trace["passed"])

    def test_debug_trace_shows_actual_dsl_branches(self) -> None:
        flow = run_case("condition-schedule")
        flow_nodes = [node for step in flow["steps"]
                      for node in step.get("effect_trace", [])]
        self.assertTrue({"sequence", "if", "for_each", "repeat", "schedule"}
                        <= {node["op"] for node in flow_nodes})
        self.assertTrue(any(node.get("branch") == "then" for node in flow_nodes))
        self.assertTrue(any(node.get("repeat_count") == 2 for node in flow_nodes))

        negative = run_case("condition-false")
        negative_nodes = [node for step in negative["steps"]
                          for node in step.get("effect_trace", [])]
        self.assertTrue(any(node.get("branch") == "else"
                            and node.get("condition_result") is False
                            for node in negative_nodes))
        self.assertFalse(any(node["ability_id"] == "TS-0001-A94"
                             for node in negative_nodes))

    def test_debug_trace_does_not_change_authoritative_result(self) -> None:
        state = start_game(request(seed="trace-parity"))["state"]
        player = state["active_player_id"]
        source = f"CI-{state['next_instance_sequence']:06d}"
        state["next_instance_sequence"] += 1
        state["instances"][source] = {
            "card_id": "TS-0437", "owner_player_id": player,
            "origin": "test_fixture", "flags": {},
        }
        state["zones"][f"player:{player}:hand"].append(source)
        entered = apply_command(state, {"type": "ChooseAction", "player_id": player,
                                        "action": "village"})["state"]
        command = {"type": "ActivateAbility", "player_id": player,
                   "ability_id": "TS-0437-A03", "source_instance_id": source}
        plain = apply_command(entered, command)
        traced = apply_command(entered, command, trace_effects=True)
        self.assertEqual(traced["state"], plain["state"])
        self.assertEqual(traced["events"], plain["events"])
        self.assertNotIn("effect_trace", plain)
        self.assertEqual([node["op"] for node in traced["effect_trace"]], ["draw"])

    def test_preview_page_and_read_only_case_api(self) -> None:
        client = TestClient(app)
        page = client.get("/effect-lab")
        self.assertEqual(page.status_code, 200)
        self.assertIn("效果处理器实验台", page.text)
        self.assertEqual(client.get("/effect-lab.js").status_code, 200)
        self.assertEqual(client.get("/effect-lab.css").status_code, 200)
        self.assertEqual(len(client.get("/effect-lab/cases").json()["cases"]), len(CASES))
        result = client.get("/effect-lab/cases/monster-count/run")
        self.assertEqual(result.status_code, 200)
        self.assertTrue(result.json()["passed"])
        self.assertEqual(client.get("/effect-lab/cases/missing/run").status_code, 404)
        self.assertEqual(client.get("/effect-lab/cases/disease-choice/run?choice_index=99").status_code, 422)


if __name__ == "__main__":
    unittest.main()
