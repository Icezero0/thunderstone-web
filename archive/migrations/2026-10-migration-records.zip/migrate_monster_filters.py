import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for name in ('build_action_effects.py', 'build_battle_effects.py', 'build_event_effects.py'):
    path = ROOT / 'scripts' / name
    source = path.read_text(encoding='utf-8')
    revised = source.replace('"subcategory": "怪物"', '"tag": "怪物"')
    revised = revised.replace('# Monster status comes from card classification, not an optional waist tag.',
                              '# Monster identity is the explicit tag, including guardians.')
    assert revised != source
    path.write_text(revised, encoding='utf-8')
path = ROOT / 'scripts/build_simple_effects.py'
source = path.read_text(encoding='utf-8')
assert 'if card["subcategory"] != "怪物":' in source
path.write_text(source.replace('if card["subcategory"] != "怪物":', 'if "怪物" not in card["tags"].split("|"):'), encoding='utf-8')

path = ROOT / 'data/effects/classic-v1.json'
source = json.loads(path.read_text(encoding='utf-8'))
def convert(value):
    if isinstance(value, dict):
        if value.get('subcategory') == '怪物':
            assert 'tag' not in value
            value = {('tag' if key == 'subcategory' else key): item for key, item in value.items()}
        return {key: convert(item) for key, item in value.items()}
    if isinstance(value, list):
        return [convert(item) for item in value]
    return value
path.write_text(json.dumps(convert(source), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
