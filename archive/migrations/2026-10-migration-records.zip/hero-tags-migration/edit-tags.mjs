import fs from 'node:fs/promises';
import { Workbook } from '@oai/artifact-tool';

const root = new URL('../../', import.meta.url);
const source = new URL('data/cards.csv', root);
const bytes = await fs.readFile(source);
await fs.writeFile(new URL('cards-before.csv', import.meta.url), bytes);
const workbook = await Workbook.fromCSV(bytes.toString('utf8').replace(/^\uFEFF/, ''), {sheetName: 'Cards'});
const sheet = workbook.worksheets.getItem('Cards');
const rows = sheet.getRange('A1:AU723').values;
const typeColumn = rows[0].indexOf('card_type');
const tagColumn = rows[0].indexOf('tags');
if (typeColumn < 0 || tagColumn < 0) throw new Error('Missing catalog columns');
const changed = [];
for (let i = 1; i < rows.length; i++) {
  if (rows[i][typeColumn] !== '英雄牌') continue;
  const tags = rows[i][tagColumn].split('|');
  if (tags.includes('英雄')) continue;
  sheet.getCell(i, tagColumn).values = [[tags.concat('英雄').join('|')]];
  changed.push(rows[i][0]);
}
const edited = sheet.getRange('A1:AU723').values;
// Preserve every non-tag string, including multiline text and numeric spelling.
for (let i = 0; i < rows.length; i++) {
  for (let j = 0; j < rows[i].length; j++) {
    if (i > 0 && j === tagColumn && changed.includes(rows[i][0])) continue;
    if (edited[i][j] !== rows[i][j]) throw new Error(`Unexpected edit at ${i},${j}`);
  }
}
await fs.writeFile(new URL('edited-rows.json', import.meta.url), JSON.stringify(edited));
console.log(JSON.stringify({changed: changed.length, sample: changed.slice(0, 3)}));
