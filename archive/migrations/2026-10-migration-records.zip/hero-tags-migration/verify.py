"""Verify source/DB parity without starting the service."""
import asyncio
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from backend.app.core.config import get_settings
from backend.app.core.database import get_engine, get_session_factory
from backend.app.modules.cards.repository import load_catalog_snapshot
from engine.catalog.repository import load_catalog
from scripts.build_setup_catalog import build

HERE = Path(__file__).resolve().parent
old = build(HERE / 'cards-before.csv')
new = build(ROOT / 'data/cards.csv')
old.pop('cards_csv_sha256')
new.pop('cards_csv_sha256')
assert old == new, 'Setup membership/order changed'
draft_path = next((ROOT / 'docs').rglob('thunderstone_card_rules_v0.3.2_engine.json'))
old_draft = json.loads((HERE / 'draft-before.json').read_bytes())
new_draft = json.loads(draft_path.read_bytes())
changed = 0
for a, b in zip(old_draft['cards'], new_draft['cards'], strict=True):
    if a['type'] == '英雄牌':
        a['tags'].append('英雄')
        changed += 1
    assert a == b, a['id']
assert old_draft == new_draft, 'Non-tag draft changes'
db_path = get_settings().sqlite_path.resolve()
assert db_path.is_relative_to(ROOT.resolve()), db_path
if '--backup' in sys.argv:
    with sqlite3.connect(str(db_path)) as source, sqlite3.connect(str(HERE / 'database-before.db')) as target:
        source.backup(target)
    print(f'Only {changed} hero tags changed; setup groups unchanged; SQLite backup saved')
else:
    snapshot = load_catalog(ROOT)
    async def verify():
        try:
            async with get_session_factory()() as db:
                assert await load_catalog_snapshot(db) == snapshot
        finally:
            await get_engine().dispose()
    asyncio.run(verify())
    with sqlite3.connect(str(db_path)) as db:
        actual = db.execute('SELECT card_id, position, tag FROM card_tags ORDER BY card_id, position').fetchall()
    expected = [(card_id, position, tag) for card_id, card in sorted(snapshot.cards.items())
                for position, tag in enumerate(filter(None, card['tags'].split('|')))]
    assert actual == expected, 'Normalized DB tags differ'
    print(f'CSV / SQLite / normalized tags match; {changed} hero definitions migrated; setup unchanged')
