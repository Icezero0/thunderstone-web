"""Losslessly serialize the edited sheet and sync draft metadata."""
import csv
import io
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
HERE = Path(__file__).resolve().parent
path = ROOT / 'data/cards.csv'
before = (HERE / 'cards-before.csv').read_bytes()
reader = csv.reader(io.StringIO(before.decode('utf-8-sig'), newline=''))
original = list(reader)
edited = json.loads((HERE / 'edited-rows.json').read_text(encoding='utf-8'))
# Artifact empty cells may be null. They are empty strings in this catalog.
edited = [['' if value is None else value for value in row] for row in edited]
assert len(edited) == len(original) == 723
assert edited[0] == original[0]
tag_index = original[0].index('tags')
type_index = original[0].index('card_type')
changed = []
for old, new in zip(original[1:], edited[1:], strict=True):
    expected = old[:]
    if old[type_index] == '英雄牌' and '英雄' not in old[tag_index].split('|'):
        expected[tag_index] += '|英雄'
        changed.append(old[0])
    assert new == expected, old[0]
assert len(changed) == 157
buffer = io.StringIO(newline='')
csv.writer(buffer).writerows(original)
assert buffer.getvalue().encode('utf-8-sig') == before, 'Unexpected source CSV formatting'
buffer = io.StringIO(newline='')
csv.writer(buffer).writerows(edited)
rendered = buffer.getvalue().encode('utf-8-sig')
draft_path = next((ROOT / 'docs').rglob('thunderstone_card_rules_v0.3.2_engine.json'))
draft_bytes = draft_path.read_bytes()
(HERE / 'draft-before.json').write_bytes(draft_bytes)
draft = json.loads(draft_bytes)
draft_changed = []
for card in draft['cards']:
    if card['id'] in changed:
        assert '英雄' not in card['tags'], card['id']
        card['tags'].append('英雄')
        draft_changed.append(card['id'])
assert set(draft_changed) == set(changed)
newline = '\n' if draft_bytes.endswith(b'\n') else ''
path.write_bytes(rendered)
draft_path.write_bytes((json.dumps(draft, ensure_ascii=False, separators=(',', ':')) + newline).encode('utf-8'))
print(f'Migrated {len(changed)} hero tags; all other CSV values preserved')
