from pathlib import Path
import asyncio
import csv
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from engine.catalog.repository import load_catalog
from backend.app.core.database import get_engine, get_session_factory
from backend.app.modules.cards.repository import load_catalog_snapshot

def read(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))

before = read(Path(__file__).with_name("cards-before.csv"))
after = read(ROOT / "data/cards.csv")
changed = []
for old, new in zip(before, after, strict=True):
    changes = [key for key in old if old[key] != new[key]]
    if changes:
        assert changes == ["tags"]
        assert new["card_type"] == "地下城牌" and new["subcategory"] in ("怪物", "守护者")
        assert new["tags"].split("|") == list(dict.fromkeys([*old["tags"].split("|"), "怪物"]))
        changed.append(new["card_id"])
assert len(changed) == 225
index_before = json.loads(Path(__file__).with_name("setup-before.json").read_text(encoding="utf-8"))
index_after = json.loads((ROOT / "data/setup_catalog.json").read_text(encoding="utf-8"))
index_before.pop("cards_csv_sha256")
index_after.pop("cards_csv_sha256")
assert index_before == index_after
draft_path = ROOT / "docs/游戏引擎设计参考/thunderstone_card_rules_v0.3.2_engine.json"
old_draft = json.loads(Path(__file__).with_name("draft-before.json").read_text(encoding="utf-8"))
new_draft = json.loads(draft_path.read_text(encoding="utf-8"))
tags = {row["card_id"]: row["tags"].split("|") for row in after}
for card in old_draft["cards"]:
    if card["id"] in changed:
        card["tags"] = tags[card["id"]]
assert old_draft == new_draft

async def check_database():
    try:
        async with get_session_factory()() as db:
            assert await load_catalog_snapshot(db) == load_catalog()
    finally:
        await get_engine().dispose()

asyncio.run(check_database())
print(json.dumps({"monster_tag_cells_changed": len(changed), "other_csv_cells_changed": 0,
                  "setup_mappings_unchanged": True, "draft_only_tags_changed": True,
                  "sqlite_matches_csv": True}))
