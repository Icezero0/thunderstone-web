import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {Workbook} from '@oai/artifact-tool';

const root = new URL('../../', import.meta.url), path = new URL('data/cards.csv', root);
const original = await fs.readFile(path, 'utf8'), bom = original.startsWith('\ufeff') ? '\ufeff' : '';
const workbook = await Workbook.fromCSV(original.replace(/^\ufeff/, ''), {sheetName: 'Cards'});
const sheet = workbook.worksheets.getItemAt(0);
const rows = sheet.getUsedRange().values.map(row => row.map(value => value == null ? '' : String(value)));
const headers = rows[0], column = name => headers.indexOf(name), tagColumn = column('tags');
const encode = table => bom + table.map(row => row.map(value => /[",\r\n]/.test(value) ? '"' + value.replaceAll('"', '""') + '"' : value).join(',')).join('\r\n') + '\r\n';
assert.equal(encode(rows), original, 'CSV round trip must preserve every original byte before editing');
const indices = rows.flatMap((row, i) => i > 0 && row[column('card_type')] === '地下城牌'
  && ['怪物', '守护者'].includes(row[column('subcategory')]) ? [i] : []);
assert.equal(indices.length, 225);
if (!process.argv.includes('--apply')) {
  console.log(JSON.stringify({rows: rows.length - 1, columns: headers.length, target_cards: indices.length,
    ordinary_monsters: indices.filter(i => rows[i][column('subcategory')] === '怪物').length,
    guardians: indices.filter(i => rows[i][column('subcategory')] === '守护者').length,
    round_trip_exact: true}));
  const first = indices[0] + 1;
  console.log((await workbook.inspect({kind: 'table', range: `Cards!O${first}:Q${first + 2}`, include: 'values', tableMaxRows: 3, tableMaxCols: 3, maxChars: 1200})).ndjson);
  const preview = await workbook.render({sheetName: 'Cards', range: `O${first}:Q${first + 2}`, scale: 1, format: 'png'});
  await fs.writeFile(new URL(process.argv.includes('--verify') ? 'after.png' : 'before.png', import.meta.url), new Uint8Array(await preview.arrayBuffer()));
} else {
  const values = rows.map(row => [row[tagColumn]]);
  for (const index of indices) {
    const tags = values[index][0].split('|').filter(Boolean);
    values[index] = [[...new Set([...tags, '怪物'])].join('|')];
  }
  sheet.getRangeByIndexes(0, tagColumn, rows.length, 1).values = values;
  workbook.recalculate();
  const updated = sheet.getUsedRange().values.map(row => row.map(value => value == null ? '' : String(value)));
  const allowed = new Set(indices);
  let changed = 0;
  for (let r = 0; r < rows.length; r++) for (let c = 0; c < headers.length; c++) {
    if (rows[r][c] !== updated[r][c]) {
      assert.ok(allowed.has(r) && c === tagColumn, `unexpected change at ${r}:${c}`); changed++;
    }
  }
  const draftPath = new URL('docs/游戏引擎设计参考/thunderstone_card_rules_v0.3.2_engine.json', root);
  const draftSource = await fs.readFile(draftPath, 'utf8'), draft = JSON.parse(draftSource);
  const ending = draftSource.endsWith('\n') ? '\n' : '';
  assert.equal(JSON.stringify(draft) + ending, draftSource, 'draft JSON round trip must preserve formatting');
  const tagById = new Map(indices.map(i => [updated[i][column('card_id')], updated[i][tagColumn].split('|')]));
  let synchronized = 0;
  for (const card of draft.cards) if (tagById.has(card.id)) {card.tags = tagById.get(card.id); synchronized++;}
  assert.equal(synchronized, 225);
  await fs.writeFile(new URL('cards-before.csv', import.meta.url), original, 'utf8');
  await fs.writeFile(new URL('setup-before.json', import.meta.url), await fs.readFile(new URL('data/setup_catalog.json', root)));
  await fs.writeFile(new URL('draft-before.json', import.meta.url), draftSource, 'utf8');
  const temporary = new URL('data/.cards-monster-tags.tmp', root);
  await fs.writeFile(temporary, encode(updated), 'utf8');
  await fs.rename(temporary, path);
  await fs.writeFile(draftPath, JSON.stringify(draft) + ending, 'utf8');
  console.log(JSON.stringify({changed_tag_cells: changed, synchronized_draft_cards: synchronized, other_cells_changed: 0}));
}
