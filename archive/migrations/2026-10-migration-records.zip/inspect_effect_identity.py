import json
from collections import Counter
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from engine.catalog.repository import load_catalog

cards = load_catalog().cards
draft = json.loads((ROOT / 'docs/游戏引擎设计参考/thunderstone_card_rules_v0.3.2_engine.json').read_text(encoding='utf-8'))
lines = {ability['id']: ability.get('source_line', '') for card in draft['cards'] for ability in card['abilities']}

def walk(value, path='$'):
    if isinstance(value, dict):
        for key, item in value.items():
            if key in ('card_type', 'subcategory', 'exclude_card_type', 'semantic_type'):
                yield path + '.' + key, key, item
            yield from walk(item, path + '.' + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk(item, path + f'[{index}]')

found = []
for name in ('classic-v1.json', 'simple-reviewed.json', 'action-reviewed.json', 'battle-reviewed.json', 'event-reviewed.json', 'mechanics.json'):
    data = json.loads((ROOT / 'data/effects' / name).read_text(encoding='utf-8'))
    for ability in data if isinstance(data, list) else data['abilities']:
        for path, key, value in walk(ability):
            found.append({'ability_id': ability['id'], 'name': cards[ability['source_card_id']]['name'],
                          'key': key, 'value': value, 'path': path, 'file': name,
                          'text': lines.get(ability['id'], ability.get('source_line', ''))})
(ROOT / 'reports/effect-classifications-before.json').write_text(json.dumps(found, ensure_ascii=False, indent=2), encoding='utf-8')
for key, value in sorted({(row['key'], row['value']) for row in found}):
    matching = [row for row in found if row['key'] == key and row['value'] == value]
    print(json.dumps({'key': key, 'value': value, 'occurrences': len(matching),
                      'abilities': len({row['ability_id'] for row in matching})}, ensure_ascii=False))
for row in {row['ability_id']: row for row in found if row['value'] == '怪物'}.values():
    print(row['ability_id'], row['name'], row['text'])
for card in cards.values():
    if card['subcategory'] == '守护者':
        print(card['card_id'], card['name'], card['effect_text'].replace('\n', ' / '))
